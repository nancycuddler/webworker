function imgProcess(binaryData) {
    for (let i = 0; i < binaryData.length; i += 4) {
        binaryData[i] = 255 - binaryData[i];
        binaryData[i + 1] = 255 - binaryData[i + 1];
        binaryData[i + 2] = 255 - binaryData[i + 2];
        binaryData[i+3] = 255;
    }
}

const ports = [];

onconnect = function(e) {
    var port = e.ports[0];
    ports.push(port);

    port.onmessage = function(e) {
        let data = e.data[0];
        imgProcess(data);
        ports.forEach(function(port) {
            port.postMessage([data, e.data[1], e.data[2]]);
        });
    }
}