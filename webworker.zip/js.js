// Người dùng chọn tệp
document.getElementById("uploadedFile").onchange = function() {
    // Mở trang mới đọc dữ liệu
    window.open("index1.html");

    // Chọn đối tượng ảnh gốc
    let nochangeImg = document.querySelector("img.nochangeImg");
    // let changedImg = document.querySelector("canvas.changedImg");

    // Tệp đã chọn
    let file = this.files[0];

    // Đọc tệp
    let reader = new FileReader();

    // Gọi lại sau khi đọc xong tệp
    reader.onload = function() {
        // Hiển thị ảnh gốc
        nochangeImg.src = reader.result;
        nochangeImg.classList.remove("noDisplay");

        // Xử lí ảnh
        setTimeout(function() {
            // Vẽ ảnh lên canvas
            // changedImg.height = nochangeImg.height;
            // changedImg.width = nochangeImg.width;
            let canvas = document.createElement("canvas");
            let context = canvas.getContext("2d");
            context.drawImage(nochangeImg, 0, 0, nochangeImg.width, nochangeImg.height);

            // Lấy dữ liệu ảnh từ canvas
            let imgData = context.getImageData(0, 0, nochangeImg.width, nochangeImg.height);
            let img = imgData.data;

            // Tạo worker xử lí ảnh
            let worker = new SharedWorker("imgChangeWk.js");

            // Gửi dữ liệu cho worker
            worker.port.postMessage([img, nochangeImg.width, nochangeImg.height]);

            // // Gọi lại khi web worker xử lí xong ảnh
            // worker.port.onmessage = function(e) {
            //     console.log(e.data);
            //     // Vẽ lại canvas với dữ liệu ảnh đã qua xử lí
            //     context.putImageData(new ImageData(e.data[0], e.data[1], e.data[2]), 0, 0);
            //     // Hiển thị canvas
            //     changedImg.classList.remove("noDisplay");
            // }
        }, 100)
    }
    
    // Đọc tệp
    if (file) reader.readAsDataURL(file);
}